function displayIfChildIsAbleToRideTheRollerCoaster(){
for(var i = 30; i <=52; i ++){
    if(i >= 52){
        console.log('Get on that ride kiddo!');
    } else {
        console.log('Sorry kiddo, maybe next year.')
    }
}
}
displayIfChildIsAbleToRideTheRollerCoaster()

